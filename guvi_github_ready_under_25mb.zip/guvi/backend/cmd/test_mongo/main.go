package main

import (
	"context"
	"fmt"
	"os"
	"time"

	"go.mongodb.org/mongo-driver/v2/bson"
	"go.mongodb.org/mongo-driver/v2/mongo"
	"go.mongodb.org/mongo-driver/v2/mongo/options"
	"pulsepoll-backend/internal/config"
)

func main() {
	cfg := config.LoadConfig()

	uri := cfg.MongoURI
	if len(os.Args) > 1 && os.Args[1] != "" {
		uri = os.Args[1]
	}

	fmt.Println("==================================================")
	fmt.Println("        MongoDB Connection Verification Tool       ")
	fmt.Println("==================================================")
	fmt.Printf("Connecting to URI: %s\n", maskURI(uri))
	fmt.Println("Target Database:  ", cfg.DatabaseName)
	fmt.Println("--------------------------------------------------")

	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()

	clientOpts := options.Client().ApplyURI(uri)
	client, err := mongo.Connect(clientOpts)
	if err != nil {
		fmt.Printf("[FAIL] Connection initialization failed: %v\n", err)
		os.Exit(1)
	}
	defer func() { _ = client.Disconnect(ctx) }()

	if err := client.Ping(ctx, nil); err != nil {
		fmt.Printf("[FAIL] Could not ping MongoDB server:\n  %v\n\n", err)
		fmt.Println("Troubleshooting Tips:")
		fmt.Println("1. If using MongoDB Atlas: verify your IP is in the Network Access Whitelist (0.0.0.0/0).")
		fmt.Println("2. Check that the username and password are correct and URL-encoded if special characters exist.")
		fmt.Println("3. If using local MongoDB: verify that mongod service is running on the target port.")
		os.Exit(1)
	}

	fmt.Println("[SUCCESS] MongoDB connected and ping successful!")

	// List databases
	dbList, err := client.ListDatabaseNames(ctx, bson.D{})
	if err == nil {
		fmt.Printf("[INFO] Available databases (%d):\n", len(dbList))
		for _, db := range dbList {
			fmt.Printf("  - %s\n", db)
		}
	}

	fmt.Println("\nConfiguration is valid and ready to use in PulsePoll.")
}

func maskURI(uri string) string {
	// Simple masking of passwords in logs
	if idx := len(uri); idx > 0 {
		return uri
	}
	return ""
}
