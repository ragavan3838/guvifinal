package config

import (
	"bufio"
	"log"
	"os"
	"strings"
)

type Config struct {
	Port          string
	MongoURI      string
	DatabaseName  string
	RedisAddr     string
	RedisPassword string
	ClientOrigin  string
}

// loadDotEnv loads key-value pairs from a .env file if present
func loadDotEnv() {
	envFiles := []string{".env", "../.env", "backend/.env"}
	for _, file := range envFiles {
		f, err := os.Open(file)
		if err != nil {
			continue
		}
		defer f.Close()

		log.Printf("[Config] Loaded environment variables from %s", file)
		scanner := bufio.NewScanner(f)
		for scanner.Scan() {
			line := strings.TrimSpace(scanner.Text())
			if line == "" || strings.HasPrefix(line, "#") {
				continue
			}
			parts := strings.SplitN(line, "=", 2)
			if len(parts) == 2 {
				key := strings.TrimSpace(parts[0])
				val := strings.TrimSpace(parts[1])
				// Strip surrounding quotes if present
				val = strings.Trim(val, `"'`)
				if os.Getenv(key) == "" {
					_ = os.Setenv(key, val)
				}
			}
		}
		break
	}
}

func LoadConfig() *Config {
	loadDotEnv()

	port := getEnv("PORT", "8080")
	mongoURI := getEnv("MONGO_URI", "mongodb://localhost:27017")
	dbName := getEnv("DB_NAME", "live_polling")
	redisAddr := getEnv("REDIS_ADDR", "localhost:6379")
	redisPassword := getEnv("REDIS_PASSWORD", "")
	clientOrigin := getEnv("CLIENT_ORIGIN", "*")

	return &Config{
		Port:          port,
		MongoURI:      mongoURI,
		DatabaseName:  dbName,
		RedisAddr:     redisAddr,
		RedisPassword: redisPassword,
		ClientOrigin:  clientOrigin,
	}
}

func getEnv(key, fallback string) string {
	if val := os.Getenv(key); val != "" {
		return val
	}
	return fallback
}
