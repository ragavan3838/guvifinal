package realtime

import (
	"context"
	"encoding/json"
	"log"
	"net/http"
	"sync"
	"time"

	"github.com/google/uuid"
	"github.com/gorilla/websocket"
	"pulsepoll-backend/internal/database"
	"pulsepoll-backend/internal/models"
)

var upgrader = websocket.Upgrader{
	ReadBufferSize:  1024,
	WriteBufferSize: 1024,
	CheckOrigin: func(r *http.Request) bool {
		return true // Allow all origins for dev/embedded
	},
}

type Client struct {
	ID     string
	PollID string
	Conn   *websocket.Conn
	Send   chan []byte
	Hub    *Hub
}

type PollRoom struct {
	PollID       string
	Clients      map[*Client]bool
	RedisSubCtx  context.CancelFunc
	mutex        sync.RWMutex
}

type Hub struct {
	Redis   *database.RedisClient
	Rooms   map[string]*PollRoom
	mu      sync.RWMutex
	RegChan chan *Client
	Unreg   chan *Client
}

func NewHub(redis *database.RedisClient) *Hub {
	return &Hub{
		Redis:   redis,
		Rooms:   make(map[string]*PollRoom),
		RegChan: make(chan *Client),
		Unreg:   make(chan *Client),
	}
}

func (h *Hub) Run() {
	for {
		select {
		case client := <-h.RegChan:
			h.registerClient(client)
		case client := <-h.Unreg:
			h.unregisterClient(client)
		}
	}
}

func (h *Hub) registerClient(client *Client) {
	h.mu.Lock()
	room, exists := h.Rooms[client.PollID]
	if !exists {
		room = &PollRoom{
			PollID:  client.PollID,
			Clients: make(map[*Client]bool),
		}
		h.Rooms[client.PollID] = room

		// Start Redis subscriber for this poll channel
		ctx, cancel := context.WithCancel(context.Background())
		room.RedisSubCtx = cancel
		go h.subscribeToRedis(ctx, room)
	}
	h.mu.Unlock()

	room.mutex.Lock()
	room.Clients[client] = true
	room.mutex.Unlock()

	// Update Redis viewer presence
	go func() {
		ctx, cancel := context.WithTimeout(context.Background(), 3*time.Second)
		defer cancel()
		count, err := h.Redis.AddViewer(ctx, client.PollID, client.ID)
		if err == nil {
			h.broadcastViewers(client.PollID, count)
		}
	}()
}

func (h *Hub) unregisterClient(client *Client) {
	h.mu.Lock()
	room, exists := h.Rooms[client.PollID]
	var shouldCleanup bool

	if exists {
		room.mutex.Lock()
		if _, ok := room.Clients[client]; ok {
			delete(room.Clients, client)
			close(client.Send)
		}
		if len(room.Clients) == 0 {
			if room.RedisSubCtx != nil {
				room.RedisSubCtx()
			}
			delete(h.Rooms, client.PollID)
			shouldCleanup = true
		}
		room.mutex.Unlock()
	}
	h.mu.Unlock()

	// Update Redis viewer count
	go func() {
		ctx, cancel := context.WithTimeout(context.Background(), 3*time.Second)
		defer cancel()
		count, err := h.Redis.RemoveViewer(ctx, client.PollID, client.ID)
		if err == nil && !shouldCleanup {
			h.broadcastViewers(client.PollID, count)
		}
	}()
}

func (h *Hub) broadcastViewers(pollId string, count int64) {
	msg := models.RealtimeMessage{
		Type:      "viewers_update",
		PollID:    pollId,
		Data:      models.ViewersPayload{Count: count},
		Timestamp: time.Now().UnixMilli(),
	}
	bytes, _ := json.Marshal(msg)
	ctx, cancel := context.WithTimeout(context.Background(), 3*time.Second)
	defer cancel()
	_ = h.Redis.PublishEvent(ctx, pollId, bytes)
}

func (h *Hub) subscribeToRedis(ctx context.Context, room *PollRoom) {
	channelName := database.PollChannel(room.PollID)
	pubsub := h.Redis.Client.Subscribe(ctx, channelName)
	defer pubsub.Close()

	ch := pubsub.Channel()
	for {
		select {
		case <-ctx.Done():
			return
		case redisMsg, ok := <-ch:
			if !ok {
				return
			}
			msgBytes := []byte(redisMsg.Payload)

			// Broadcast payload to all clients in room
			room.mutex.RLock()
			for client := range room.Clients {
				select {
				case client.Send <- msgBytes:
				default:
					// Slow client
				}
			}
			room.mutex.RUnlock()
		}
	}
}

// Client readPump pumps messages from websocket connection to the hub/redis
func (c *Client) ReadPump() {
	defer func() {
		c.Hub.Unreg <- c
		c.Conn.Close()
	}()

	c.Conn.SetReadLimit(4096)
	_ = c.Conn.SetReadDeadline(time.Now().Add(60 * time.Second))
	c.Conn.SetPongHandler(func(string) error {
		_ = c.Conn.SetReadDeadline(time.Now().Add(60 * time.Second))
		return nil
	})

	for {
		_, message, err := c.Conn.ReadMessage()
		if err != nil {
			break
		}

		// Handle client-initiated messages (e.g., reaction sent over WS)
		var incoming struct {
			Type  string          `json:"type"`
			Data  json.RawMessage `json:"data"`
			Emoji string          `json:"emoji"`
		}
		if err := json.Unmarshal(message, &incoming); err == nil {
			if incoming.Type == "reaction" && incoming.Emoji != "" {
				reactionMsg := models.RealtimeMessage{
					Type:   "reaction",
					PollID: c.PollID,
					Data: models.ReactionPayload{
						ID:    uuid.New().String(),
						Emoji: incoming.Emoji,
					},
					Timestamp: time.Now().UnixMilli(),
				}
				bytes, _ := json.Marshal(reactionMsg)
				ctx, cancel := context.WithTimeout(context.Background(), 2*time.Second)
				_ = c.Hub.Redis.PublishEvent(ctx, c.PollID, bytes)
				cancel()
			}
		}
	}
}

// Client writePump pumps messages from the hub to the websocket connection
func (c *Client) WritePump() {
	ticker := time.NewTicker(25 * time.Second)
	defer func() {
		ticker.Stop()
		c.Conn.Close()
	}()

	for {
		select {
		case message, ok := <-c.Send:
			_ = c.Conn.SetWriteDeadline(time.Now().Add(10 * time.Second))
			if !ok {
				_ = c.Conn.WriteMessage(websocket.CloseMessage, []byte{})
				return
			}

			w, err := c.Conn.NextWriter(websocket.TextMessage)
			if err != nil {
				return
			}
			_, _ = w.Write(message)
			if err := w.Close(); err != nil {
				return
			}

		case <-ticker.C:
			_ = c.Conn.SetWriteDeadline(time.Now().Add(10 * time.Second))
			if err := c.Conn.WriteMessage(websocket.PingMessage, nil); err != nil {
				return
			}
		}
	}
}

// ServeWS upgrades the HTTP connection to WebSocket and initializes the client
func (h *Hub) ServeWS(w http.ResponseWriter, r *http.Request, pollId string) {
	conn, err := upgrader.Upgrade(w, r, nil)
	if err != nil {
		log.Println("[WebSocket] Upgrade error:", err)
		return
	}

	client := &Client{
		ID:     uuid.New().String(),
		PollID: pollId,
		Conn:   conn,
		Send:   make(chan []byte, 256),
		Hub:    h,
	}

	h.RegChan <- client

	go client.WritePump()
	go client.ReadPump()
}
