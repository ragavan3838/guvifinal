# ⚡ PulsePoll — Real-Time Live Polling Engine

A modern, high-performance live polling tool where organizers create polls, share links or QR codes, and audiences vote with results updating across all watching screens in real time with zero refresh.

Built with **React**, **Go (Gin)**, **MongoDB**, and **Redis**.

---

## 🏗️ Architecture & Technology Stack

Each layer is engineered to do critical, real work:

```
                  ┌─────────────────────────────────┐
                  │          React Frontend         │
                  │ (Vite, Tailwind, QR, Confetti)  │
                  └──────────────┬──────────────────┘
                                 │ HTTP / WebSockets
                                 ▼
                  ┌─────────────────────────────────┐
                  │       Go Backend (Gin)          │
                  │   REST API + WebSocket Hub      │
                  └───────┬─────────────────┬───────┘
                          │                 │
             Atomic Write │                 │ Cold Storage
            & Pub/Sub Bus │                 │ & Audit Log
                          ▼                 ▼
                  ┌───────────────┐ ┌───────────────┐
                  │     Redis     │ │    MongoDB    │
                  │ • HINCRBY     │ │ • Poll Config │
                  │ • SADD Voters │ │ • Options     │
                  │ • Pub/Sub Bus │ │ • Vote Audit  │
                  │ • Viewer Pres │ │ • Auth Tokens │
                  └───────────────┘ └───────────────┘
```

| Layer | Technology | Primary Role in the System |
| :--- | :--- | :--- |
| **Frontend** | **React (Vite + Tailwind CSS)** | Mobile-first voting interface, animated real-time results bar charts, full-screen presenter mode with live QR code, and floating reaction particle system. |
| **Backend** | **Go (Gin Framework)** | Compiled high-throughput HTTP REST API, Gorilla WebSocket connection manager, and Redis Pub/Sub multiplexer. |
| **Database** | **MongoDB** | Persistent source of truth for poll configuration, option metadata, creator security tokens, and comprehensive vote audit logs. |
| **Realtime** | **Redis** | In-memory atomic vote counters (`HINCRBY`), unique voter tracking (`SADD`), active viewer presence, and real-time Pub/Sub broadcast bus (`channel:poll:{id}`). |

---

## 🚀 Key Features

1. **Effortless Poll Creation Studio**:
   - Customizable questions, descriptions, and dynamic options.
   - Per-option custom colors and emoji badges.
   - Built-in presets: "Tech Stack", "Yes / No", "Rating (1-5)".
   - Real-time mobile phone preview showing exactly how the poll appears to attendees as you type.
   - Settings for multi-choice voting, voter name prompt, and auto-close timers.

2. **Audience Mobile Voting Experience**:
   - Fast, tactile voting interface accessible from any mobile or desktop browser.
   - Single-tap or multi-select options.
   - Instant celebration with a confetti explosion upon submitting a vote.
   - Prevents double-voting via local token and server-side Redis set validation (`SADD`).
   - Live audience reaction bar (🔥, ❤️, 👏, 🎉, 🚀, 💡, 💯) allowing attendees to cheer and react in real-time.

3. **Live Results & Charts**:
   - Zero-lag animated percentage bars updating automatically as votes are counted.
   - Live vote counts and leading option crowning.
   - Active viewer counter: "🟢 14 watching".
   - Creator controls: Close/Reopen voting, Reset votes, and Export audit data (JSON).

4. **Projector / Presentation Mode**:
   - Fullscreen distraction-free view designed for conferences, meetups, and lecture halls.
   - Large QR code for attendees to point their phone cameras and vote immediately.
   - Floating reactions stream across the projector screen as participants tap reactions.

5. **My Polls Dashboard**:
   - Quick access to all polls created on the local browser with direct links to vote, view live results, or present.

---

## 🛠️ Running the Project Locally

### ⚡ One-Click Run (Windows)
You can start everything and launch your browser in one step:
- **Double-click** [`run.bat`](file:///c:/Users/Lenovo/Desktop/guvi/run.bat) or run in terminal:
```cmd
run.bat
```
- Or using PowerShell:
```powershell
powershell -ExecutionPolicy Bypass -File .\run.ps1
```

### ⚙️ Connecting a Manual MongoDB Database
You can point PulsePoll to any local or cloud MongoDB database (including **MongoDB Atlas**):

1. Open [`backend/.env`](file:///c:/Users/Lenovo/Desktop/guvi/backend/.env)
2. Update the `MONGO_URI` with your connection string:
   - **Local instance (default)**:
     ```env
     MONGO_URI=mongodb://127.0.0.1:27017
     ```
   - **Local with Authentication**:
     ```env
     MONGO_URI=mongodb://username:password@127.0.0.1:27017/live_polling?authSource=admin
     ```
   - **MongoDB Atlas (Cloud)**:
     ```env
     MONGO_URI=mongodb+srv://username:password@cluster0.abcde.mongodb.net/live_polling?retryWrites=true&w=majority
     ```
3. Test your connection string immediately:
   ```bash
   npm run test:mongo
   ```
   *or pass a URI directly:*
   ```bash
   cd backend && go run ./cmd/test_mongo "mongodb+srv://username:password@cluster..."
   ```

---

### Prerequisites
- **Go** (v1.20+)
- **Node.js** (v18+) and **npm**
- **MongoDB** (running on `localhost:27017` or Atlas URI)
- **Redis** (running on `localhost:6379`)

### 1. Start Redis & MongoDB
Ensure both MongoDB and Redis services are active:
```bash
# Verify MongoDB on port 27017
# Verify Redis on port 6379 (e.g. redis-server)
```

### 2. Start the Go Backend
```bash
cd backend
go run ./cmd/server
```
*The backend starts at `http://localhost:8080`.*

### 3. Start the React Frontend
```bash
cd frontend
npm install
npm run dev
```
*The frontend starts at `http://localhost:5173`.*

---

## 🧪 Automated End-to-End Verification

An automated end-to-end integration test is included that tests poll creation, native WebSocket streaming, atomic vote counting, and live reaction broadcasting:

```bash
node test_realtime.cjs
```

---

## 📡 API Reference

### REST Endpoints
- `GET  /api/health` — Check health status of MongoDB, Redis, and Go server.
- `POST /api/polls` — Create a new poll. Returns poll metadata and creator token.
- `GET  /api/polls/:id` — Retrieve poll details with real-time vote totals from Redis.
- `POST /api/polls/:id/vote` — Submit a vote (`{ voterId, optionIds, voterName }`).
- `POST /api/polls/:id/reaction` — Send a live emoji reaction (`{ emoji: "🔥" }`).
- `PATCH /api/polls/:id/state` — Toggle poll open/closed (requires creator token).
- `POST /api/polls/:id/reset` — Reset all votes (requires creator token).
- `GET  /api/polls/:id/export` — Export vote audit logs from MongoDB.

### WebSocket Endpoint
- `ws://localhost:8080/ws/poll/:id` — Real-time bidirectional connection streaming `vote_update`, `reaction`, `viewers_update`, and `state_change` events via Redis Pub/Sub.
