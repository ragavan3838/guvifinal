import React, { useState } from 'react';
import { 
  Plus, Trash2, Sparkles, Settings2, Clock, CheckCircle2, 
  ArrowRight, Smartphone, HelpCircle, Palette, Flame 
} from 'lucide-react';
import { createPoll, saveCreatedPoll } from '../services/api';

const PRESETS = [
  {
    name: 'Tech Stack',
    title: 'Which backend technology do you find most productive in 2026?',
    options: [
      { text: 'Go (Golang)', emoji: '⚡', color: '#6366F1' },
      { text: 'Node.js / TypeScript', emoji: '🟢', color: '#10B981' },
      { text: 'Rust', emoji: '🦀', color: '#F59E0B' },
      { text: 'Python (FastAPI)', emoji: '🐍', color: '#3B82F6' },
    ]
  },
  {
    name: 'Yes / No',
    title: 'Should we adopt microservices for the upcoming project?',
    options: [
      { text: 'Yes, definitely', emoji: '👍', color: '#10B981' },
      { text: 'No, monolith first', emoji: '✋', color: '#EF4444' },
      { text: 'Undecided / Need spike', emoji: '🤔', color: '#F59E0B' },
    ]
  },
  {
    name: 'Rating (1-5)',
    title: 'How would you rate today\'s live demonstration?',
    options: [
      { text: '⭐⭐⭐⭐⭐ Mind-blowing', emoji: '🚀', color: '#8B5CF6' },
      { text: '⭐⭐⭐⭐ Great insights', emoji: '💡', color: '#6366F1' },
      { text: '⭐⭐⭐ Average', emoji: '👌', color: '#3B82F6' },
      { text: '⭐⭐ Could improve', emoji: '📝', color: '#EC4899' },
    ]
  }
];

const COLOR_PALETTE = ['#6366F1', '#EC4899', '#10B981', '#F59E0B', '#8B5CF6', '#3B82F6', '#14B8A6', '#EF4444'];
const EMOJI_PALETTE = ['⚡', '🔥', '🚀', '✨', '🎯', '💡', '🌟', '🎉', '❤️', '👍', '🦀', '🐍'];

export default function CreatePoll({ onPollCreated }) {
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [options, setOptions] = useState([
    { text: 'Go (Golang)', color: '#6366F1', emoji: '⚡' },
    { text: 'Node.js', color: '#EC4899', emoji: '🚀' },
    { text: 'Rust', color: '#10B981', emoji: '🦀' },
  ]);
  const [allowMultiple, setAllowMultiple] = useState(false);
  const [requireName, setRequireName] = useState(false);
  const [showResultsImmediate, setShowResultsImmediate] = useState(true);
  const [durationMinutes, setDurationMinutes] = useState(0); // 0 = no expiry
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState('');

  const handleAddOption = () => {
    if (options.length >= 10) return;
    const color = COLOR_PALETTE[options.length % COLOR_PALETTE.length];
    const emoji = EMOJI_PALETTE[options.length % EMOJI_PALETTE.length];
    setOptions([...options, { text: '', color, emoji }]);
  };

  const handleRemoveOption = (index) => {
    if (options.length <= 2) {
      setError('A poll must have at least 2 options.');
      return;
    }
    setOptions(options.filter((_, i) => i !== index));
    setError('');
  };

  const handleOptionChange = (index, field, value) => {
    const next = [...options];
    next[index][field] = value;
    setOptions(next);
  };

  const applyPreset = (preset) => {
    setTitle(preset.title);
    setOptions(preset.options);
    setError('');
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!title.trim()) {
      setError('Please provide a question or poll title.');
      return;
    }
    for (let opt of options) {
      if (!opt.text.trim()) {
        setError('All options must contain text.');
        return;
      }
    }

    setIsSubmitting(true);
    setError('');

    let expiresAt = null;
    if (durationMinutes > 0) {
      expiresAt = new Date(Date.now() + durationMinutes * 60 * 1000).toISOString();
    }

    try {
      const payload = {
        title: title.trim(),
        description: description.trim(),
        options: options.map(o => ({
          text: o.text.trim(),
          color: o.color,
          emoji: o.emoji,
        })),
        settings: {
          allowMultiple,
          requireName,
          showResultsImmediate,
          expiresAt: expiresAt ? new Date(expiresAt) : null,
        }
      };

      const res = await createPoll(payload);
      saveCreatedPoll(res.poll, res.creatorToken);
      if (onPollCreated) {
        onPollCreated(res.poll, res.creatorToken);
      }
    } catch (err) {
      setError(err.message || 'Failed to create poll');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8">
      
      {/* Hero Header */}
      <div className="mb-8 text-center sm:text-left sm:flex sm:items-center sm:justify-between">
        <div>
          <h1 className="text-3xl font-extrabold tracking-tight text-white sm:text-4xl">
            Create a Live Poll
          </h1>
          <p className="mt-2 text-sm text-slate-400 max-w-xl">
            Launch interactive polls in seconds. Powered by Redis Pub/Sub for sub-millisecond live updates across all attendee screens.
          </p>
        </div>

        {/* Quick Presets */}
        <div className="mt-4 sm:mt-0 flex flex-wrap items-center gap-2">
          <span className="text-xs font-semibold text-slate-400 flex items-center gap-1">
            <Sparkles className="h-3.5 w-3.5 text-indigo-400" /> Presets:
          </span>
          {PRESETS.map((p) => (
            <button
              key={p.name}
              type="button"
              onClick={() => applyPreset(p)}
              className="rounded-lg border border-slate-800 bg-slate-900 px-3 py-1.5 text-xs font-medium text-slate-300 hover:border-indigo-500/50 hover:text-white transition-colors"
            >
              {p.name}
            </button>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        
        {/* Main Editor Form */}
        <div className="lg:col-span-7">
          <form onSubmit={handleSubmit} className="space-y-6 rounded-2xl border border-slate-800/80 bg-slate-900/60 p-6 sm:p-8 backdrop-blur-xl shadow-xl">
            
            {error && (
              <div className="rounded-xl border border-rose-500/30 bg-rose-500/10 p-3.5 text-xs text-rose-300 font-medium animate-in fade-in">
                {error}
              </div>
            )}

            {/* Poll Question */}
            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-400 mb-2">
                Poll Question *
              </label>
              <input
                type="text"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="e.g. Which cloud provider is best for latency-sensitive APIs?"
                className="w-full rounded-xl border border-slate-700 bg-slate-950 px-4 py-3 text-sm text-white placeholder-slate-500 focus:border-indigo-500 focus:outline-none focus:ring-1 focus:ring-indigo-500 transition-all"
                required
              />
            </div>

            {/* Description / Subtext */}
            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-400 mb-2">
                Description / Context <span className="text-slate-500 font-normal">(optional)</span>
              </label>
              <textarea
                rows={2}
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="Add context or guidelines for participants..."
                className="w-full rounded-xl border border-slate-700 bg-slate-950 px-4 py-2.5 text-sm text-white placeholder-slate-500 focus:border-indigo-500 focus:outline-none focus:ring-1 focus:ring-indigo-500 transition-all resize-none"
              />
            </div>

            {/* Poll Options List */}
            <div>
              <div className="flex items-center justify-between mb-2.5">
                <label className="text-xs font-bold uppercase tracking-wider text-slate-400">
                  Voting Options ({options.length}/10) *
                </label>
                <button
                  type="button"
                  onClick={handleAddOption}
                  disabled={options.length >= 10}
                  className="inline-flex items-center gap-1.5 text-xs font-semibold text-indigo-400 hover:text-indigo-300 disabled:opacity-40 transition-colors"
                >
                  <Plus className="h-4 w-4" />
                  Add Option
                </button>
              </div>

              <div className="space-y-3">
                {options.map((opt, idx) => (
                  <div key={idx} className="flex items-center gap-2 group">
                    {/* Emoji badge */}
                    <div className="relative">
                      <input
                        type="text"
                        maxLength={2}
                        value={opt.emoji}
                        onChange={(e) => handleOptionChange(idx, 'emoji', e.target.value)}
                        className="h-10 w-10 text-center text-lg rounded-xl border border-slate-700 bg-slate-950 text-white focus:border-indigo-500 focus:outline-none"
                        title="Change emoji"
                      />
                    </div>

                    {/* Option Text Input */}
                    <div className="relative flex-1">
                      <input
                        type="text"
                        value={opt.text}
                        onChange={(e) => handleOptionChange(idx, 'text', e.target.value)}
                        placeholder={`Option ${idx + 1}`}
                        className="w-full rounded-xl border border-slate-700 bg-slate-950 px-4 py-2.5 text-sm text-white placeholder-slate-500 focus:border-indigo-500 focus:outline-none focus:ring-1 focus:ring-indigo-500 transition-all pr-12"
                        required
                      />
                      {/* Color dot picker */}
                      <div className="absolute right-3 top-1/2 -translate-y-1/2 flex items-center">
                        <input
                          type="color"
                          value={opt.color}
                          onChange={(e) => handleOptionChange(idx, 'color', e.target.value)}
                          className="h-5 w-5 rounded cursor-pointer border-none bg-transparent"
                          title="Pick accent color"
                        />
                      </div>
                    </div>

                    {/* Delete Option */}
                    <button
                      type="button"
                      onClick={() => handleRemoveOption(idx)}
                      disabled={options.length <= 2}
                      className="rounded-lg p-2 text-slate-500 hover:bg-slate-800 hover:text-rose-400 disabled:opacity-20 transition-colors"
                    >
                      <Trash2 className="h-4 w-4" />
                    </button>
                  </div>
                ))}
              </div>
            </div>

            {/* Poll Configuration & Rules */}
            <div className="rounded-xl border border-slate-800 bg-slate-950/60 p-4 space-y-3.5">
              <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-slate-300">
                <Settings2 className="h-4 w-4 text-indigo-400" />
                <span>Poll Settings</span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                {/* Allow Multiple */}
                <label className="flex items-center gap-2.5 rounded-lg border border-slate-800 p-2.5 cursor-pointer hover:bg-slate-900 transition-colors">
                  <input
                    type="checkbox"
                    checked={allowMultiple}
                    onChange={(e) => setAllowMultiple(e.target.checked)}
                    className="h-4 w-4 rounded border-slate-700 bg-slate-900 text-indigo-600 focus:ring-indigo-500"
                  />
                  <div>
                    <div className="font-semibold text-slate-200">Multiple Choices</div>
                    <div className="text-[11px] text-slate-400">Audience can pick &gt;1 option</div>
                  </div>
                </label>

                {/* Require Nickname */}
                <label className="flex items-center gap-2.5 rounded-lg border border-slate-800 p-2.5 cursor-pointer hover:bg-slate-900 transition-colors">
                  <input
                    type="checkbox"
                    checked={requireName}
                    onChange={(e) => setRequireName(e.target.checked)}
                    className="h-4 w-4 rounded border-slate-700 bg-slate-900 text-indigo-600 focus:ring-indigo-500"
                  />
                  <div>
                    <div className="font-semibold text-slate-200">Ask for Name</div>
                    <div className="text-[11px] text-slate-400">Voters enter their nickname</div>
                  </div>
                </label>

                {/* Immediate Results */}
                <label className="flex items-center gap-2.5 rounded-lg border border-slate-800 p-2.5 cursor-pointer hover:bg-slate-900 transition-colors">
                  <input
                    type="checkbox"
                    checked={showResultsImmediate}
                    onChange={(e) => setShowResultsImmediate(e.target.checked)}
                    className="h-4 w-4 rounded border-slate-700 bg-slate-900 text-indigo-600 focus:ring-indigo-500"
                  />
                  <div>
                    <div className="font-semibold text-slate-200">Show Live Results</div>
                    <div className="text-[11px] text-slate-400">Reveal charts immediately</div>
                  </div>
                </label>

                {/* Expiry Timer */}
                <div className="rounded-lg border border-slate-800 p-2.5 flex flex-col justify-between">
                  <div className="font-semibold text-slate-200 flex items-center gap-1.5">
                    <Clock className="h-3.5 w-3.5 text-indigo-400" />
                    <span>Auto-close Timer</span>
                  </div>
                  <select
                    value={durationMinutes}
                    onChange={(e) => setDurationMinutes(Number(e.target.value))}
                    className="mt-1.5 w-full rounded border border-slate-700 bg-slate-900 px-2 py-1 text-xs text-slate-300 focus:outline-none"
                  >
                    <option value={0}>No limit (manual close)</option>
                    <option value={5}>5 minutes</option>
                    <option value={15}>15 minutes</option>
                    <option value={60}>1 hour</option>
                    <option value={1440}>24 hours</option>
                  </select>
                </div>
              </div>
            </div>

            {/* Launch Button */}
            <button
              type="submit"
              disabled={isSubmitting}
              className="w-full flex items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-indigo-600 via-indigo-500 to-purple-600 py-3.5 px-6 font-bold text-white shadow-lg shadow-indigo-500/25 hover:from-indigo-500 hover:to-purple-500 active:scale-[0.99] disabled:opacity-50 transition-all cursor-pointer"
            >
              <span>{isSubmitting ? 'Creating Poll...' : 'Launch Live Poll'}</span>
              <ArrowRight className="h-4 w-4" />
            </button>

          </form>
        </div>

        {/* Live Audience Preview Phone Mockup */}
        <div className="lg:col-span-5">
          <div className="sticky top-24">
            <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-slate-400 mb-3">
              <Smartphone className="h-4 w-4 text-indigo-400" />
              <span>Audience Live Preview</span>
            </div>

            {/* Phone Container */}
            <div className="relative mx-auto max-w-sm rounded-[2.5rem] border-4 border-slate-800 bg-slate-950 p-4 shadow-2xl">
              {/* Speaker / Notch Bar */}
              <div className="mx-auto h-4 w-28 rounded-full bg-slate-800 mb-4" />

              <div className="space-y-4 px-2 pb-4">
                {/* Live Pulse pill in preview */}
                <div className="flex justify-between items-center">
                  <span className="flex items-center gap-1.5 text-[11px] font-semibold text-emerald-400 bg-emerald-500/10 border border-emerald-500/20 px-2.5 py-0.5 rounded-full">
                    <span className="h-1.5 w-1.5 rounded-full bg-emerald-500 animate-ping" />
                    LIVE
                  </span>
                  <span className="text-[11px] text-slate-500 font-mono">Mobile View</span>
                </div>

                {/* Poll Title */}
                <div>
                  <h3 className="text-base font-bold text-white leading-snug">
                    {title || 'What is your question?'}
                  </h3>
                  {description && (
                    <p className="mt-1 text-xs text-slate-400">{description}</p>
                  )}
                </div>

                {/* Options Preview */}
                <div className="space-y-2 pt-2">
                  {options.map((opt, i) => (
                    <div
                      key={i}
                      className="flex items-center justify-between rounded-xl border border-slate-800/80 bg-slate-900/80 px-3.5 py-3 transition-colors hover:border-slate-700"
                    >
                      <div className="flex items-center gap-2.5">
                        <span className="text-base">{opt.emoji || '⚡'}</span>
                        <span className="text-xs font-semibold text-slate-200">
                          {opt.text || `Option ${i + 1}`}
                        </span>
                      </div>
                      <div
                        className="h-3 w-3 rounded-full"
                        style={{ backgroundColor: opt.color || '#6366F1' }}
                      />
                    </div>
                  ))}
                </div>

                {/* Submit button preview */}
                <div className="pt-2">
                  <div className="w-full rounded-xl bg-indigo-600/80 py-2.5 text-center text-xs font-bold text-white">
                    Submit Vote
                  </div>
                </div>

                {/* Real-time Reaction bar preview */}
                <div className="flex justify-center gap-2 pt-2 border-t border-slate-800/60">
                  {['🔥', '❤️', '👏', '🎉', '🚀'].map((em) => (
                    <span key={em} className="text-sm opacity-60 hover:opacity-100 transition-opacity">
                      {em}
                    </span>
                  ))}
                </div>

              </div>
            </div>
          </div>
        </div>

      </div>

    </div>
  );
}
