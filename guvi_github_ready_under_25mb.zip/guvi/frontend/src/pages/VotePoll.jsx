import React, { useState, useEffect } from 'react';
import confetti from 'canvas-confetti';
import { 
  CheckCircle2, AlertCircle, BarChart3, Radio, Send, 
  Flame, Heart, Sparkles, Trophy, Lock, User
} from 'lucide-react';
import { getPoll, submitVote, getLocalVote, recordLocalVote } from '../services/api';
import { usePollSocket } from '../hooks/usePollSocket';
import LiveBadge from '../components/LiveBadge';
import ReactionOverlay from '../components/ReactionOverlay';

const REACTIONS = ['🔥', '❤️', '👏', '🎉', '🚀', '💡', '💯'];

export default function VotePoll({ pollId, onViewResults }) {
  const [poll, setPoll] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [selectedOptions, setSelectedOptions] = useState([]);
  const [voterName, setVoterName] = useState('');
  const [hasVoted, setHasVoted] = useState(false);
  const [myVoteOptions, setMyVoteOptions] = useState([]);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const {
    isConnected,
    liveVotes,
    totalVotes,
    totalVoters,
    viewersCount,
    isClosed: socketIsClosed,
    reactions,
    triggerReaction,
    setInitialState,
  } = usePollSocket(pollId);

  useEffect(() => {
    async function load() {
      try {
        setLoading(true);
        const data = await getPoll(pollId);
        setPoll(data.poll);
        setInitialState(data.poll);

        // Check if previously voted
        const local = getLocalVote(pollId);
        if (local) {
          setHasVoted(true);
          setMyVoteOptions(local.optionIds || []);
        }
      } catch (err) {
        setError(err.message || 'Poll not found');
      } finally {
        setLoading(false);
      }
    }
    load();
  }, [pollId, setInitialState]);

  const isClosed = socketIsClosed || poll?.isClosed;

  const handleOptionToggle = (optionId) => {
    if (isClosed || hasVoted) return;

    if (poll?.settings?.allowMultiple) {
      if (selectedOptions.includes(optionId)) {
        setSelectedOptions(selectedOptions.filter(id => id !== optionId));
      } else {
        setSelectedOptions([...selectedOptions, optionId]);
      }
    } else {
      setSelectedOptions([optionId]);
    }
  };

  const handleSubmitVote = async (e) => {
    e.preventDefault();
    if (selectedOptions.length === 0) {
      setError('Please choose at least one option.');
      return;
    }
    if (poll?.settings?.requireName && !voterName.trim()) {
      setError('Please enter your name or nickname.');
      return;
    }

    setIsSubmitting(true);
    setError('');

    try {
      await submitVote(pollId, {
        optionIds: selectedOptions,
        voterName: voterName.trim(),
      });

      // Confetti celebration!
      try {
        confetti({
          particleCount: 80,
          spread: 70,
          origin: { y: 0.65 },
        });
      } catch (e) {
        // ignore confetti errors
      }

      recordLocalVote(pollId, selectedOptions);
      setHasVoted(true);
      setMyVoteOptions(selectedOptions);
    } catch (err) {
      setError(err.message || 'Vote submission failed');
    } finally {
      setIsSubmitting(false);
    }
  };

  if (loading) {
    return (
      <div className="flex min-h-[60vh] items-center justify-center">
        <div className="flex flex-col items-center gap-3">
          <div className="h-8 w-8 animate-spin rounded-full border-2 border-indigo-500 border-t-transparent" />
          <p className="text-xs font-mono text-slate-400">Loading poll...</p>
        </div>
      </div>
    );
  }

  if (error && !poll) {
    return (
      <div className="mx-auto max-w-lg px-4 py-16 text-center">
        <div className="mx-auto mb-4 flex h-14 w-14 items-center justify-center rounded-2xl bg-rose-500/10 text-rose-400">
          <AlertCircle className="h-7 w-7" />
        </div>
        <h2 className="text-xl font-bold text-white">Poll Not Available</h2>
        <p className="mt-2 text-sm text-slate-400">{error}</p>
      </div>
    );
  }

  return (
    <div className="relative min-h-[85vh] px-4 py-8 sm:py-12">
      <ReactionOverlay reactions={reactions} />

      <div className="mx-auto max-w-xl">
        
        {/* Top Status Bar */}
        <div className="mb-6 flex items-center justify-between">
          <LiveBadge 
            isConnected={isConnected} 
            viewersCount={viewersCount} 
            isClosed={isClosed} 
          />

          <button
            onClick={() => onViewResults(pollId)}
            className="flex items-center gap-1.5 rounded-lg border border-slate-800 bg-slate-900 px-3 py-1.5 text-xs font-medium text-slate-300 hover:border-slate-700 hover:text-white transition-colors"
          >
            <BarChart3 className="h-3.5 w-3.5 text-indigo-400" />
            <span>Live Results</span>
          </button>
        </div>

        {/* Poll Card */}
        <div className="rounded-3xl border border-slate-800/90 bg-slate-900/80 p-6 sm:p-8 backdrop-blur-xl shadow-2xl">
          
          {/* Header */}
          <div className="mb-6">
            <h1 className="text-2xl font-black tracking-tight text-white sm:text-3xl leading-snug">
              {poll.title}
            </h1>
            {poll.description && (
              <p className="mt-2 text-sm text-slate-400">
                {poll.description}
              </p>
            )}

            <div className="mt-4 flex flex-wrap items-center gap-2 text-[11px] text-slate-400 font-medium">
              <span className="rounded-md bg-slate-800 px-2 py-0.5">
                {poll.settings.allowMultiple ? 'Multiple choices allowed' : 'Single choice only'}
              </span>
              <span>•</span>
              <span className="font-mono">{totalVotes} total votes</span>
            </div>
          </div>

          {error && (
            <div className="mb-4 rounded-xl border border-rose-500/30 bg-rose-500/10 p-3 text-xs text-rose-300 font-medium">
              {error}
            </div>
          )}

          {/* If already voted */}
          {hasVoted ? (
            <div className="space-y-6 animate-in fade-in slide-in-from-bottom-2">
              <div className="rounded-2xl border border-emerald-500/30 bg-emerald-500/10 p-4 text-center">
                <div className="mx-auto mb-2 flex h-10 w-10 items-center justify-center rounded-full bg-emerald-500/20 text-emerald-400">
                  <CheckCircle2 className="h-5 w-5" />
                </div>
                <h4 className="text-sm font-bold text-emerald-300">Your Vote is Recorded!</h4>
                <p className="mt-1 text-xs text-slate-300">
                  Watch results update in real-time as other participants submit their votes.
                </p>
              </div>

              {/* Real-time Result Bars */}
              <div className="space-y-3">
                {poll.options.map((opt) => {
                  const count = liveVotes[opt.id] ?? opt.voteCount ?? 0;
                  const pct = totalVotes > 0 ? Math.round((count / totalVotes) * 100) : 0;
                  const isMyPick = myVoteOptions.includes(opt.id);

                  return (
                    <div
                      key={opt.id}
                      className={`relative overflow-hidden rounded-2xl border p-4 transition-all ${
                        isMyPick 
                          ? 'border-indigo-500/60 bg-indigo-500/10 ring-1 ring-indigo-500/30' 
                          : 'border-slate-800 bg-slate-950/60'
                      }`}
                    >
                      {/* Animated Progress Fill */}
                      <div
                        className="absolute inset-y-0 left-0 transition-all duration-700 ease-out opacity-20"
                        style={{
                          width: `${pct}%`,
                          backgroundColor: opt.color || '#6366F1',
                        }}
                      />

                      <div className="relative flex items-center justify-between">
                        <div className="flex items-center gap-3">
                          <span className="text-lg">{opt.emoji || '⚡'}</span>
                          <div>
                            <span className="text-sm font-semibold text-white">
                              {opt.text}
                            </span>
                            {isMyPick && (
                              <span className="ml-2 inline-flex items-center rounded bg-indigo-500/30 px-1.5 py-0.5 text-[10px] font-bold text-indigo-300">
                                Your Choice
                              </span>
                            )}
                          </div>
                        </div>

                        <div className="flex items-baseline gap-2 font-mono">
                          <span className="text-sm font-bold text-white">{pct}%</span>
                          <span className="text-xs text-slate-500">({count})</span>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>

              {/* View Presentation / Full Results button */}
              <div className="pt-2">
                <button
                  onClick={() => onViewResults(pollId)}
                  className="w-full flex items-center justify-center gap-2 rounded-xl bg-slate-800 hover:bg-slate-700 py-3 text-xs font-bold text-white transition-colors"
                >
                  <BarChart3 className="h-4 w-4 text-indigo-400" />
                  <span>Open Full Presentation Screen</span>
                </button>
              </div>

            </div>
          ) : isClosed ? (
            /* Poll Closed Notice */
            <div className="rounded-2xl border border-slate-800 bg-slate-950 p-6 text-center space-y-3">
              <div className="mx-auto flex h-10 w-10 items-center justify-center rounded-full bg-rose-500/10 text-rose-400">
                <Lock className="h-5 w-5" />
              </div>
              <h3 className="text-base font-bold text-white">Voting is Closed</h3>
              <p className="text-xs text-slate-400">
                The organizer has closed this poll. You can still inspect the final live results.
              </p>
              <button
                onClick={() => onViewResults(pollId)}
                className="mt-2 inline-flex items-center gap-1.5 rounded-lg bg-indigo-600 px-4 py-2 text-xs font-semibold text-white hover:bg-indigo-500 transition-colors"
              >
                <span>View Final Results</span>
              </button>
            </div>
          ) : (
            /* Voting Form */
            <form onSubmit={handleSubmitVote} className="space-y-5">
              
              {/* Optional Name Input */}
              {poll.settings.requireName && (
                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-slate-400 mb-2">
                    Your Name / Nickname *
                  </label>
                  <div className="relative">
                    <User className="absolute left-3.5 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-500" />
                    <input
                      type="text"
                      value={voterName}
                      onChange={(e) => setVoterName(e.target.value)}
                      placeholder="e.g. Alex"
                      className="w-full rounded-xl border border-slate-700 bg-slate-950 pl-10 pr-4 py-2.5 text-sm text-white placeholder-slate-500 focus:border-indigo-500 focus:outline-none"
                      required
                    />
                  </div>
                </div>
              )}

              {/* Options Selection */}
              <div className="space-y-2.5">
                {poll.options.map((opt) => {
                  const isSelected = selectedOptions.includes(opt.id);

                  return (
                    <div
                      key={opt.id}
                      onClick={() => handleOptionToggle(opt.id)}
                      className={`group flex items-center justify-between rounded-2xl border p-4 cursor-pointer transition-all ${
                        isSelected
                          ? 'border-indigo-500 bg-indigo-500/15 shadow-lg shadow-indigo-500/10 ring-2 ring-indigo-500/40'
                          : 'border-slate-800 bg-slate-950/70 hover:border-slate-700 hover:bg-slate-950'
                      }`}
                    >
                      <div className="flex items-center gap-3.5">
                        <span className="text-xl group-hover:scale-110 transition-transform">{opt.emoji || '⚡'}</span>
                        <span className={`text-sm font-semibold transition-colors ${isSelected ? 'text-white' : 'text-slate-200'}`}>
                          {opt.text}
                        </span>
                      </div>

                      <div className={`flex h-5 w-5 items-center justify-center rounded-full border transition-all ${
                        isSelected
                          ? 'border-indigo-500 bg-indigo-600 text-white'
                          : 'border-slate-700 bg-slate-900 group-hover:border-slate-600'
                      }`}>
                        {isSelected && <CheckCircle2 className="h-3.5 w-3.5" />}
                      </div>
                    </div>
                  );
                })}
              </div>

              {/* Submit Vote Button */}
              <button
                type="submit"
                disabled={isSubmitting || selectedOptions.length === 0}
                className="w-full flex items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-indigo-600 to-purple-600 py-3.5 px-6 font-bold text-white shadow-lg shadow-indigo-500/25 hover:from-indigo-500 hover:to-purple-500 active:scale-[0.99] disabled:opacity-40 transition-all cursor-pointer"
              >
                <Send className="h-4 w-4" />
                <span>{isSubmitting ? 'Recording Vote...' : 'Submit My Vote'}</span>
              </button>

            </form>
          )}

        </div>

        {/* Live Audience Reactions Bar */}
        <div className="mt-6 rounded-2xl border border-slate-800/70 bg-slate-900/60 p-3.5 backdrop-blur-md">
          <div className="flex items-center justify-between px-1 mb-2">
            <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400 flex items-center gap-1">
              <Sparkles className="h-3 w-3 text-indigo-400" /> Send Live Reaction
            </span>
            <span className="text-[10px] text-slate-500 font-mono">Floats to all viewers</span>
          </div>

          <div className="flex items-center justify-around gap-1">
            {REACTIONS.map((emoji) => (
              <button
                key={emoji}
                type="button"
                onClick={() => triggerReaction(emoji)}
                className="flex h-11 w-11 items-center justify-center rounded-xl bg-slate-800/80 text-xl transition-all hover:scale-125 hover:bg-slate-700 active:scale-95 cursor-pointer shadow"
                title={`Send ${emoji}`}
              >
                {emoji}
              </button>
            ))}
          </div>
        </div>

      </div>
    </div>
  );
}
