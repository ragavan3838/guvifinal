import React, { useState, useEffect } from 'react';
import { 
  BarChart3, Users, Crown, QrCode, Share2, 
  Lock, Unlock, RotateCcw, Download, Tv, ArrowLeft,
  Sparkles, CheckCircle, ExternalLink
} from 'lucide-react';
import { getPoll, togglePollState, resetPoll, exportVotes, getSavedPolls } from '../services/api';
import { usePollSocket } from '../hooks/usePollSocket';
import LiveBadge from '../components/LiveBadge';
import ReactionOverlay from '../components/ReactionOverlay';
import QRCodeModal from '../components/QRCodeModal';

const REACTIONS = ['🔥', '❤️', '👏', '🎉', '🚀', '💡', '💯'];

export default function LiveResults({ pollId, onBackToVote, onOpenPresent }) {
  const [poll, setPoll] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [creatorToken, setCreatorToken] = useState('');
  const [showQR, setShowQR] = useState(false);
  const [copied, setCopied] = useState(false);
  const [actionLoading, setActionLoading] = useState(false);

  const {
    isConnected,
    liveVotes,
    totalVotes,
    totalVoters,
    viewersCount,
    isClosed: socketIsClosed,
    reactions,
    triggerReaction,
    setInitialState,
  } = usePollSocket(pollId);

  useEffect(() => {
    async function load() {
      try {
        setLoading(true);
        // Find if we have saved creator token
        const saved = getSavedPolls().find(p => p.id === pollId);
        const token = saved?.creatorToken || '';
        setCreatorToken(token);

        const data = await getPoll(pollId, token);
        setPoll(data.poll);
        setInitialState(data.poll);
        if (data.poll.creatorToken) {
          setCreatorToken(data.poll.creatorToken);
        }
      } catch (err) {
        setError(err.message || 'Poll not found');
      } finally {
        setLoading(false);
      }
    }
    load();
  }, [pollId, setInitialState]);

  const isClosed = socketIsClosed || poll?.isClosed;
  const isCreator = Boolean(creatorToken);

  // Compute leader / winner
  let maxVotes = 0;
  let leaderId = null;
  (poll?.options || []).forEach(opt => {
    const count = liveVotes[opt.id] ?? opt.voteCount ?? 0;
    if (count > maxVotes) {
      maxVotes = count;
      leaderId = opt.id;
    }
  });

  const handleToggleState = async () => {
    if (!isCreator || actionLoading) return;
    try {
      setActionLoading(true);
      await togglePollState(pollId, {
        creatorToken,
        isClosed: !isClosed,
      });
      setPoll(prev => ({ ...prev, isClosed: !isClosed }));
    } catch (err) {
      alert('Failed to toggle poll state: ' + err.message);
    } finally {
      setActionLoading(false);
    }
  };

  const handleReset = async () => {
    if (!isCreator || actionLoading) return;
    if (!window.confirm('Are you sure you want to reset all votes for this poll? This cannot be undone.')) {
      return;
    }
    try {
      setActionLoading(true);
      await resetPoll(pollId, creatorToken);
    } catch (err) {
      alert('Failed to reset poll: ' + err.message);
    } finally {
      setActionLoading(false);
    }
  };

  const handleExport = async () => {
    if (!isCreator) return;
    try {
      const data = await exportVotes(pollId, creatorToken);
      const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `poll_${pollId}_audit_export.json`;
      a.click();
      URL.revokeObjectURL(url);
    } catch (err) {
      alert('Export failed: ' + err.message);
    }
  };

  const handleCopyLink = () => {
    const url = `${window.location.origin}/#poll=${pollId}`;
    navigator.clipboard.writeText(url);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  if (loading) {
    return (
      <div className="flex min-h-[60vh] items-center justify-center">
        <div className="flex flex-col items-center gap-3">
          <div className="h-8 w-8 animate-spin rounded-full border-2 border-indigo-500 border-t-transparent" />
          <p className="text-xs font-mono text-slate-400">Loading live results...</p>
        </div>
      </div>
    );
  }

  if (error && !poll) {
    return (
      <div className="mx-auto max-w-lg px-4 py-16 text-center text-slate-400">
        <p>{error}</p>
      </div>
    );
  }

  return (
    <div className="relative min-h-[85vh] px-4 py-8 sm:py-12">
      <ReactionOverlay reactions={reactions} />

      <div className="mx-auto max-w-4xl">
        
        {/* Navigation & Header Controls */}
        <div className="mb-6 flex flex-wrap items-center justify-between gap-4">
          
          <div className="flex items-center gap-3">
            <button
              onClick={onBackToVote}
              className="flex items-center gap-1.5 rounded-lg border border-slate-800 bg-slate-900 px-3 py-1.5 text-xs font-medium text-slate-300 hover:border-slate-700 hover:text-white transition-colors"
            >
              <ArrowLeft className="h-3.5 w-3.5" />
              <span>Back to Vote</span>
            </button>

            <LiveBadge 
              isConnected={isConnected} 
              viewersCount={viewersCount} 
              isClosed={isClosed} 
            />
          </div>

          {/* Action Tools */}
          <div className="flex items-center gap-2">
            <button
              onClick={() => setShowQR(true)}
              className="flex items-center gap-1.5 rounded-lg border border-slate-800 bg-slate-900 px-3 py-1.5 text-xs font-semibold text-slate-300 hover:border-indigo-500/40 hover:text-white transition-colors"
            >
              <QrCode className="h-3.5 w-3.5 text-indigo-400" />
              <span>QR Code</span>
            </button>

            <button
              onClick={handleCopyLink}
              className="flex items-center gap-1.5 rounded-lg border border-slate-800 bg-slate-900 px-3 py-1.5 text-xs font-semibold text-slate-300 hover:border-indigo-500/40 hover:text-white transition-colors"
            >
              {copied ? <CheckCircle className="h-3.5 w-3.5 text-emerald-400" /> : <Share2 className="h-3.5 w-3.5 text-indigo-400" />}
              <span>{copied ? 'Copied Link!' : 'Share'}</span>
            </button>

            <button
              onClick={() => onOpenPresent(pollId)}
              className="flex items-center gap-1.5 rounded-lg bg-indigo-600 px-3.5 py-1.5 text-xs font-bold text-white shadow-md shadow-indigo-600/30 hover:bg-indigo-500 transition-all active:scale-95"
            >
              <Tv className="h-3.5 w-3.5" />
              <span>Present</span>
            </button>
          </div>

        </div>

        {/* Main Results Panel */}
        <div className="rounded-3xl border border-slate-800/90 bg-slate-900/80 p-6 sm:p-10 backdrop-blur-xl shadow-2xl">
          
          {/* Poll Title & Stats Row */}
          <div className="mb-8 border-b border-slate-800/80 pb-6 sm:flex sm:items-start sm:justify-between">
            <div className="max-w-2xl">
              <h1 className="text-2xl font-black tracking-tight text-white sm:text-4xl leading-tight">
                {poll.title}
              </h1>
              {poll.description && (
                <p className="mt-2 text-sm text-slate-400">
                  {poll.description}
                </p>
              )}
            </div>

            {/* Quick Stat Counters */}
            <div className="mt-4 sm:mt-0 flex sm:flex-col items-center sm:items-end gap-3 sm:gap-1">
              <div className="flex items-baseline gap-1.5">
                <span className="text-3xl font-black font-mono text-white tracking-tight">
                  {totalVotes}
                </span>
                <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider">
                  votes
                </span>
              </div>
              <span className="text-[11px] font-mono text-slate-500">
                {totalVoters} unique voters
              </span>
            </div>
          </div>

          {/* Options Result Bars */}
          <div className="space-y-4">
            {poll.options.map((opt) => {
              const count = liveVotes[opt.id] ?? opt.voteCount ?? 0;
              const pct = totalVotes > 0 ? Math.round((count / totalVotes) * 100) : 0;
              const isLeader = maxVotes > 0 && count === maxVotes;

              return (
                <div
                  key={opt.id}
                  className={`group relative overflow-hidden rounded-2xl border transition-all duration-300 ${
                    isLeader && totalVotes > 0
                      ? 'border-indigo-500/50 bg-slate-950 shadow-lg shadow-indigo-500/10'
                      : 'border-slate-800/90 bg-slate-950/70'
                  }`}
                >
                  {/* Dynamic Animated Horizontal Bar */}
                  <div
                    className="absolute inset-y-0 left-0 transition-all duration-700 ease-out"
                    style={{
                      width: `${pct}%`,
                      backgroundColor: opt.color || '#6366F1',
                      opacity: isLeader && totalVotes > 0 ? 0.35 : 0.2,
                    }}
                  />

                  <div className="relative flex items-center justify-between p-4 sm:p-5">
                    
                    {/* Option Details */}
                    <div className="flex items-center gap-3 sm:gap-4">
                      <span className="text-2xl sm:text-3xl select-none group-hover:scale-110 transition-transform">
                        {opt.emoji || '⚡'}
                      </span>
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="text-base sm:text-lg font-bold text-white">
                            {opt.text}
                          </span>
                          {isLeader && totalVotes > 0 && (
                            <span className="inline-flex items-center gap-1 rounded-full bg-amber-400/15 border border-amber-400/30 px-2 py-0.5 text-[10px] font-bold text-amber-300">
                              <Crown className="h-3 w-3" /> Leading
                            </span>
                          )}
                        </div>
                        <span className="text-xs font-mono text-slate-400">
                          {count} {count === 1 ? 'vote' : 'votes'}
                        </span>
                      </div>
                    </div>

                    {/* Percentage Display */}
                    <div className="text-right">
                      <div className="text-2xl sm:text-3xl font-black font-mono text-white tracking-tight">
                        {pct}%
                      </div>
                      <div className="h-1.5 w-16 sm:w-24 rounded-full bg-slate-800 overflow-hidden mt-1">
                        <div
                          className="h-full rounded-full transition-all duration-700"
                          style={{
                            width: `${pct}%`,
                            backgroundColor: opt.color || '#6366F1',
                          }}
                        />
                      </div>
                    </div>

                  </div>
                </div>
              );
            })}
          </div>

          {/* Organizer / Creator Controls */}
          {isCreator && (
            <div className="mt-10 rounded-2xl border border-slate-800 bg-slate-950/60 p-5">
              <div className="flex items-center justify-between mb-3 border-b border-slate-800/80 pb-3">
                <span className="text-xs font-bold uppercase tracking-wider text-slate-300 flex items-center gap-1.5">
                  <Crown className="h-3.5 w-3.5 text-indigo-400" /> Organizer Controls
                </span>
                <span className="text-[10px] font-mono text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/20">
                  Creator Verified
                </span>
              </div>

              <div className="flex flex-wrap items-center gap-3">
                {/* Close / Open Toggle */}
                <button
                  onClick={handleToggleState}
                  disabled={actionLoading}
                  className={`flex items-center gap-2 rounded-xl px-4 py-2.5 text-xs font-bold transition-all active:scale-95 ${
                    isClosed
                      ? 'bg-emerald-600 hover:bg-emerald-500 text-white shadow-emerald-600/20'
                      : 'bg-rose-600/90 hover:bg-rose-500 text-white shadow-rose-600/20'
                  }`}
                >
                  {isClosed ? <Unlock className="h-3.5 w-3.5" /> : <Lock className="h-3.5 w-3.5" />}
                  <span>{isClosed ? 'Reopen Voting' : 'Close / Pause Voting'}</span>
                </button>

                {/* Reset Votes */}
                <button
                  onClick={handleReset}
                  disabled={actionLoading}
                  className="flex items-center gap-2 rounded-xl border border-slate-800 bg-slate-900 hover:border-rose-500/40 hover:text-rose-300 px-4 py-2.5 text-xs font-semibold text-slate-300 transition-colors"
                >
                  <RotateCcw className="h-3.5 w-3.5 text-slate-400" />
                  <span>Reset Votes</span>
                </button>

                {/* Export Data */}
                <button
                  onClick={handleExport}
                  className="flex items-center gap-2 rounded-xl border border-slate-800 bg-slate-900 hover:border-indigo-500/40 hover:text-white px-4 py-2.5 text-xs font-semibold text-slate-300 transition-colors"
                >
                  <Download className="h-3.5 w-3.5 text-slate-400" />
                  <span>Export Audit Data (JSON)</span>
                </button>
              </div>
            </div>
          )}

        </div>

        {/* Live Audience Reactions Footer Bar */}
        <div className="mt-6 rounded-2xl border border-slate-800/70 bg-slate-900/60 p-3.5 backdrop-blur-md">
          <div className="flex items-center justify-between px-1 mb-2">
            <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400 flex items-center gap-1">
              <Sparkles className="h-3 w-3 text-indigo-400" /> Send Live Reaction
            </span>
            <span className="text-[10px] text-slate-500 font-mono">Floats to all viewers</span>
          </div>

          <div className="flex items-center justify-around gap-1">
            {REACTIONS.map((emoji) => (
              <button
                key={emoji}
                type="button"
                onClick={() => triggerReaction(emoji)}
                className="flex h-11 w-11 items-center justify-center rounded-xl bg-slate-800/80 text-xl transition-all hover:scale-125 hover:bg-slate-700 active:scale-95 cursor-pointer shadow"
                title={`Send ${emoji}`}
              >
                {emoji}
              </button>
            ))}
          </div>
        </div>

      </div>

      <QRCodeModal
        poll={poll}
        isOpen={showQR}
        onClose={() => setShowQR(false)}
        onOpenPresent={() => {
          setShowQR(false);
          onOpenPresent(pollId);
        }}
      />
    </div>
  );
}
